# Tanzania AI 🇹🇿

Toleo la kwanza la interface ya Tanzania AI.

## Mafaili
- `index.html` — ukurasa mkuu
- `style.css` — muonekano
- `app.js` — tabia za ukurasa

## Hatua inayofuata
Unganisha backend na AI API kwa kutumia API key kwenye server-side environment variable. Usipachike API key ndani ya `index.html` au `app.js`.
