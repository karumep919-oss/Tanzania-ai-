const prompt = document.getElementById("prompt");
const answer = document.getElementById("answer");
document.getElementById("ask").addEventListener("click", () => {
  const text = prompt.value.trim();
  if (!text) {
    answer.textContent = "Andika swali kwanza.";
    return;
  }
  answer.textContent =
    "Karibu Tanzania AI 🇹🇿. Mfumo huu wa mwanzo uko tayari kuunganishwa na AI API. Kwa sasa umepokea: " + text;
});
